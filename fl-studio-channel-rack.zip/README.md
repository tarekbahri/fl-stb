# FL Studio Channel Rack & Step Sequencer

A standalone Web Audio API drum machine, 16-step sequencer, and inline Graph Editor inspired by FL Studio and designed for touch controls on iPhone Safari and desktop browsers.

## Included Files
- `index.html` — Application layout and transport/rack UI structure.
- `style.css` — Dark FL Studio theme, responsive Portrait/Landscape touch styles, and step/graph editor styling.
- `app.js` — Web Audio API synthesis engine (8 core instruments + extras), Lookahead Scheduler, Graph Editor (Velocity & Pitch), Pattern 1–8 management, and ZIP exporter.
- `README.md` — Setup and usage guide.

## How to Run
1. Extract `fl-studio-channel-rack.zip` into a folder.
2. Open `index.html` directly in Safari, Chrome, or Edge — or serve the folder via any local static web server:
   - `npx serve .`
   - or `python3 -m http.server 8080`

## Features
- **8 Synthesized Instruments (Zero external audio files):** Kick, 808 Sub, Snare, Clap, Rimshot, Closed Hat, Open Hat, Crash / Perc (plus Add Channel presets).
- **Patterns 1–8 + Clone Pattern:** Switch across 8 patterns and clone any pattern including steps, velocity, and pitch.
- **Graph Editor:** Edit per-step Velocity (0–100%) and Pitch (±12 semitones) directly underneath the selected channel.
- **Touch Controls:** Drag Pan/Volume knobs and BPM vertically, swipe across steps to paint, and adjust Global Swing (0–100%).
- **Quick Channel Options:** Fill each 2 steps, Fill each 4 steps, Clear, Clone, Reorder, Delete, and Color Picker.
