(() => {
      'use strict';

      /* ================= CONSTANTS & 8 CORE INSTRUMENTS ================= */
      const PATTERN_COUNT = 8;
      const STEPS_COUNT = 16;
      const DEFAULT_VEL = 0.78;
      const DEFAULT_PITCH = 0; // semitones (-12 to +12)

      const CHANNEL_COLORS = [
        '#4c6d94', // FL Steel Blue
        '#9c5555', // 808 Crimson
        '#5a8a59', // Snare Sage
        '#b87a38', // Clap Amber
        '#8a7842', // Rimshot Gold
        '#448488', // Closed Hat Teal
        '#775996', // Open Hat Violet
        '#c2623c', // Crash Sienna
        '#3d7ca8', // Cobalt
        '#a84f73', // Rose
        '#58997e', // Mint
        '#697380'  // Slate
      ];

      const SYNTH_PRESETS = [
        { type: 'kick',      name: 'Kick',         color: '#4c6d94' },
        { type: 'sub808',    name: '808 Sub',      color: '#9c5555' },
        { type: 'snare',     name: 'Snare',        color: '#5a8a59' },
        { type: 'clap',      name: 'Clap',         color: '#b87a38' },
        { type: 'rimshot',   name: 'Rimshot',      color: '#8a7842' },
        { type: 'closedHat', name: 'Closed Hat',   color: '#448488' },
        { type: 'openHat',   name: 'Open Hat',     color: '#775996' },
        { type: 'crashPerc', name: 'Crash / Perc', color: '#c2623c' },
        { type: 'tom',       name: 'Low Tom',      color: '#3d7ca8' },
        { type: 'pluck',     name: 'Synth Pluck',  color: '#a84f73' }
      ];

      let nextId = 1;
      function makeId() {
        return 'ch_' + (nextId++);
      }

      const initialChannels = [
        { id: makeId(), name: 'Kick',         type: 'kick',      color: '#4c6d94', pan: 0,     volume: 0.88, muted: false },
        { id: makeId(), name: '808 Sub',      type: 'sub808',    color: '#9c5555', pan: 0,     volume: 0.86, muted: false },
        { id: makeId(), name: 'Snare',        type: 'snare',     color: '#5a8a59', pan: 0,     volume: 0.80, muted: false },
        { id: makeId(), name: 'Clap',         type: 'clap',      color: '#b87a38', pan: 0.08,  volume: 0.74, muted: false },
        { id: makeId(), name: 'Rimshot',      type: 'rimshot',   color: '#8a7842', pan: -0.22, volume: 0.68, muted: false },
        { id: makeId(), name: 'Closed Hat',   type: 'closedHat', color: '#448488', pan: -0.15, volume: 0.68, muted: false },
        { id: makeId(), name: 'Open Hat',     type: 'openHat',   color: '#775996', pan: 0.22,  volume: 0.62, muted: false },
        { id: makeId(), name: 'Crash / Perc', type: 'crashPerc', color: '#c2623c', pan: 0.14,  volume: 0.60, muted: false }
      ];

      function makeChannelPatternData() {
        return {
          steps: new Array(STEPS_COUNT).fill(false),
          velocity: new Array(STEPS_COUNT).fill(DEFAULT_VEL),
          pitch: new Array(STEPS_COUNT).fill(DEFAULT_PITCH)
        };
      }

      function createEmptyPattern(channels) {
        const pat = {};
        channels.forEach(ch => {
          pat[ch.id] = makeChannelPatternData();
        });
        return pat;
      }

      function createStarterPatterns(channels) {
        const patterns = Array.from({ length: PATTERN_COUNT }, () => createEmptyPattern(channels));
        const [kick, sub, snare, clap, rim, chat, ohat, crash] = channels;

        // Pattern 1: Hard Trap / Hip-Hop Beat with pitched 808 & hat rolls
        patterns[0][kick.id].steps  = [1,0,0,0, 0,0,1,0, 0,0,1,0, 0,0,0,0].map(Boolean);
        patterns[0][sub.id].steps   = [1,0,0,1, 0,0,1,0, 0,0,1,0, 0,1,0,0].map(Boolean);
        patterns[0][sub.id].pitch   = [0,0,0,3, 0,0,5,0, 0,0,0,0, 0,7,0,0];
        patterns[0][snare.id].steps = [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0].map(Boolean);
        patterns[0][clap.id].steps  = [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,1].map(Boolean);
        patterns[0][clap.id].velocity = [0.78,0.78,0.78,0.78, 0.88,0.78,0.78,0.78, 0.78,0.78,0.78,0.78, 0.88,0.78,0.78,0.48];
        patterns[0][rim.id].steps   = [0,0,1,0, 0,0,0,0, 0,1,0,0, 0,0,0,0].map(Boolean);
        patterns[0][chat.id].steps  = [1,0,1,0, 1,0,1,1, 1,0,1,0, 1,1,1,0].map(Boolean);
        patterns[0][chat.id].velocity = [0.85,0.6,0.65,0.6, 0.85,0.6,0.7,0.48, 0.85,0.6,0.65,0.6, 0.85,0.52,0.42,0.6];
        patterns[0][chat.id].pitch  = [0,0,0,0, 0,0,0,-2, 0,0,0,0, 0,-3,-5,0];
        patterns[0][ohat.id].steps  = [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,1].map(Boolean);
        patterns[0][crash.id].steps = [1,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0].map(Boolean);

        // Pattern 2: Punchy House / Bounce Variation
        patterns[1][kick.id].steps  = [1,0,0,0, 1,0,0,0, 1,0,0,0, 1,0,0,0].map(Boolean);
        patterns[1][sub.id].steps   = [0,0,1,0, 0,0,1,0, 0,0,1,0, 0,0,1,1].map(Boolean);
        patterns[1][sub.id].pitch   = [0,0,0,0, 0,0,3,0, 0,0,5,0, 0,0,2,-2];
        patterns[1][snare.id].steps = [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0].map(Boolean);
        patterns[1][clap.id].steps  = [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,1,0].map(Boolean);
        patterns[1][chat.id].steps  = [0,0,1,0, 0,0,1,0, 0,0,1,0, 0,0,1,0].map(Boolean);
        patterns[1][ohat.id].steps  = [0,0,0,0, 0,0,0,1, 0,0,0,0, 0,0,0,1].map(Boolean);

        return patterns;
      }

      const state = {
        bpm: 132,
        swing: 18,
        currentPattern: 0,
        selectedChannelId: initialChannels[0].id,
        graphEditorOpen: false,
        graphMode: 'velocity', // 'velocity' | 'pitch'
        channels: initialChannels,
        patterns: createStarterPatterns(initialChannels),
        isPlaying: false,
        currentStep: -1
      };

      /* ================= WEB AUDIO API ENGINE (iOS SAFARI OPTIMIZED) ================= */
      let audioCtx = null;
      let masterComp = null;
      let masterGain = null;
      let noiseBuffer = null;
      let softClipCurve = null;
      let bassSatCurve = null;
      let openHatStopFn = null;

      function makeDistortionCurve(amount) {
        const n = 256;
        const curve = new Float32Array(n);
        for (let i = 0; i < n; i++) {
          const x = (i * 2) / n - 1;
          curve[i] = ((3 + amount) * x * 20 * (Math.PI / 180)) / (Math.PI + amount * Math.abs(x));
        }
        return curve;
      }

      function ensureAudioContext() {
        if (!audioCtx) {
          const AudioCtx = window.AudioContext || window.webkitAudioContext;
          audioCtx = new AudioCtx({ latencyHint: 'interactive' });

          masterComp = audioCtx.createDynamicsCompressor();
          masterComp.threshold.setValueAtTime(-9, audioCtx.currentTime);
          masterComp.knee.setValueAtTime(10, audioCtx.currentTime);
          masterComp.ratio.setValueAtTime(4, audioCtx.currentTime);
          masterComp.attack.setValueAtTime(0.002, audioCtx.currentTime);
          masterComp.release.setValueAtTime(0.14, audioCtx.currentTime);

          masterGain = audioCtx.createGain();
          masterGain.gain.setValueAtTime(0.92, audioCtx.currentTime);

          masterComp.connect(masterGain);
          masterGain.connect(audioCtx.destination);

          // Pre-allocate 1.5s white noise buffer once
          const len = Math.floor(audioCtx.sampleRate * 1.5);
          noiseBuffer = audioCtx.createBuffer(1, len, audioCtx.sampleRate);
          const data = noiseBuffer.getChannelData(0);
          for (let i = 0; i < len; i++) {
            data[i] = Math.random() * 2 - 1;
          }

          softClipCurve = makeDistortionCurve(18);
          bassSatCurve = makeDistortionCurve(34);
        }
        if (audioCtx.state === 'suspended') {
          audioCtx.resume();
        }
        return audioCtx;
      }

      function unlockIOSAudio() {
        const ctx = ensureAudioContext();
        const buf = ctx.createBuffer(1, 1, 22050);
        const src = ctx.createBufferSource();
        src.buffer = buf;
        src.connect(ctx.destination);
        src.start(0);
        window.removeEventListener('touchstart', unlockIOSAudio, true);
        window.removeEventListener('pointerdown', unlockIOSAudio, true);
      }
      window.addEventListener('touchstart', unlockIOSAudio, true);
      window.addEventListener('pointerdown', unlockIOSAudio, true);

      function createChannelOutput(ctx, channel, velocity) {
        const gain = ctx.createGain();
        const vol = Math.max(0, Math.min(1, channel.volume));
        const vel = Math.max(0.04, Math.min(1, velocity));
        gain.gain.setValueAtTime(vol * vol * vel, ctx.currentTime);

        if (typeof ctx.createStereoPanner === 'function') {
          const panner = ctx.createStereoPanner();
          panner.pan.setValueAtTime(Math.max(-1, Math.min(1, channel.pan)), ctx.currentTime);
          gain.connect(panner);
          panner.connect(masterComp);
        } else {
          gain.connect(masterComp);
        }
        return gain;
      }

      function triggerSound(channel, time, velocity = DEFAULT_VEL, pitchSemitones = 0) {
        const ctx = ensureAudioContext();
        const t = time || ctx.currentTime;
        const out = createChannelOutput(ctx, channel, velocity);
        const pitchRatio = Math.pow(2, pitchSemitones / 12);

        switch (channel.type) {
          case 'kick': {
            const osc = ctx.createOscillator();
            const env = ctx.createGain();
            const shaper = ctx.createWaveShaper();
            shaper.curve = softClipCurve;

            osc.type = 'sine';
            osc.frequency.setValueAtTime(165 * pitchRatio, t);
            osc.frequency.exponentialRampToValueAtTime(52 * pitchRatio, t + 0.042);
            osc.frequency.exponentialRampToValueAtTime(36 * pitchRatio, t + 0.28);

            env.gain.setValueAtTime(1.15, t);
            env.gain.exponentialRampToValueAtTime(0.45, t + 0.085);
            env.gain.exponentialRampToValueAtTime(0.001, t + 0.35);

            osc.connect(shaper);
            shaper.connect(env);
            env.connect(out);
            osc.start(t);
            osc.stop(t + 0.36);

            // Punch transient click
            const clickOsc = ctx.createOscillator();
            const clickGain = ctx.createGain();
            clickOsc.type = 'triangle';
            clickOsc.frequency.setValueAtTime(1450 * pitchRatio, t);
            clickOsc.frequency.exponentialRampToValueAtTime(140 * pitchRatio, t + 0.015);
            clickGain.gain.setValueAtTime(0.36, t);
            clickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.018);
            clickOsc.connect(clickGain);
            clickGain.connect(out);
            clickOsc.start(t);
            clickOsc.stop(t + 0.02);
            break;
          }

          case 'sub808': {
            const osc = ctx.createOscillator();
            const sub = ctx.createOscillator();
            const shaper = ctx.createWaveShaper();
            shaper.curve = bassSatCurve;

            const lp = ctx.createBiquadFilter();
            lp.type = 'lowpass';
            lp.frequency.setValueAtTime(360 * pitchRatio, t);
            lp.frequency.exponentialRampToValueAtTime(150 * pitchRatio, t + 0.35);

            const env = ctx.createGain();
            osc.type = 'triangle';
            sub.type = 'sine';

            const baseFreq = 49 * pitchRatio; // G1 root
            osc.frequency.setValueAtTime(125 * pitchRatio, t);
            osc.frequency.exponentialRampToValueAtTime(baseFreq, t + 0.04);
            sub.frequency.setValueAtTime(125 * pitchRatio, t);
            sub.frequency.exponentialRampToValueAtTime(baseFreq, t + 0.04);

            env.gain.setValueAtTime(0.001, t);
            env.gain.linearRampToValueAtTime(0.96, t + 0.006);
            env.gain.exponentialRampToValueAtTime(0.58, t + 0.22);
            env.gain.exponentialRampToValueAtTime(0.001, t + 0.56);

            osc.connect(shaper);
            shaper.connect(lp);
            sub.connect(lp);
            lp.connect(env);
            env.connect(out);

            osc.start(t);
            sub.start(t);
            osc.stop(t + 0.58);
            sub.stop(t + 0.58);
            break;
          }

          case 'snare': {
            const body = ctx.createOscillator();
            const bodyGain = ctx.createGain();
            body.type = 'triangle';
            body.frequency.setValueAtTime(215 * pitchRatio, t);
            body.frequency.exponentialRampToValueAtTime(125 * pitchRatio, t + 0.085);
            bodyGain.gain.setValueAtTime(0.58, t);
            bodyGain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
            body.connect(bodyGain);
            bodyGain.connect(out);
            body.start(t);
            body.stop(t + 0.15);

            const noise = ctx.createBufferSource();
            noise.buffer = noiseBuffer;
            const hp = ctx.createBiquadFilter();
            hp.type = 'highpass';
            hp.frequency.setValueAtTime(Math.max(400, 1400 * pitchRatio), t);
            const nGain = ctx.createGain();
            nGain.gain.setValueAtTime(0.76, t);
            nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.21);
            noise.connect(hp);
            hp.connect(nGain);
            nGain.connect(out);
            noise.start(t);
            noise.stop(t + 0.22);
            break;
          }

          case 'clap': {
            const bursts = [0, 0.011, 0.022, 0.032];
            bursts.forEach((offset, idx) => {
              const noise = ctx.createBufferSource();
              noise.buffer = noiseBuffer;
              const bp = ctx.createBiquadFilter();
              bp.type = 'bandpass';
              bp.frequency.setValueAtTime(Math.max(400, 1280 * pitchRatio), t + offset);
              bp.Q.setValueAtTime(1.4, t + offset);

              const g = ctx.createGain();
              const isTail = idx === bursts.length - 1;
              const dur = isTail ? 0.24 : 0.022;
              g.gain.setValueAtTime(isTail ? 0.68 : 0.52, t + offset);
              g.gain.exponentialRampToValueAtTime(0.001, t + offset + dur);

              noise.connect(bp);
              bp.connect(g);
              g.connect(out);
              noise.start(t + offset);
              noise.stop(t + offset + dur + 0.01);
            });
            break;
          }

          case 'rimshot': {
            const osc = ctx.createOscillator();
            const bp = ctx.createBiquadFilter();
            const g = ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(1680 * pitchRatio, t);
            osc.frequency.exponentialRampToValueAtTime(460 * pitchRatio, t + 0.024);

            bp.type = 'bandpass';
            bp.frequency.setValueAtTime(1250 * pitchRatio, t);
            bp.Q.setValueAtTime(2.2, t);

            g.gain.setValueAtTime(0.82, t);
            g.gain.exponentialRampToValueAtTime(0.001, t + 0.055);
            osc.connect(bp);
            bp.connect(g);
            g.connect(out);
            osc.start(t);
            osc.stop(t + 0.06);
            break;
          }

          case 'closedHat': {
            if (openHatStopFn) {
              try { openHatStopFn(t); } catch (_) {}
              openHatStopFn = null;
            }
            const ratios = [205, 304, 370, 523, 540, 800];
            const hp = ctx.createBiquadFilter();
            hp.type = 'highpass';
            hp.frequency.setValueAtTime(Math.min(16000, 7200 * pitchRatio), t);
            const bp = ctx.createBiquadFilter();
            bp.type = 'bandpass';
            bp.frequency.setValueAtTime(Math.min(18000, 10200 * pitchRatio), t);
            bp.Q.setValueAtTime(0.8, t);

            const g = ctx.createGain();
            g.gain.setValueAtTime(0.45, t);
            g.gain.exponentialRampToValueAtTime(0.001, t + 0.055);

            hp.connect(bp);
            bp.connect(g);
            g.connect(out);

            ratios.forEach(freq => {
              const osc = ctx.createOscillator();
              osc.type = 'square';
              osc.frequency.setValueAtTime(freq * pitchRatio, t);
              osc.connect(hp);
              osc.start(t);
              osc.stop(t + 0.065);
            });

            const noise = ctx.createBufferSource();
            noise.buffer = noiseBuffer;
            const nGain = ctx.createGain();
            nGain.gain.setValueAtTime(0.28, t);
            nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
            noise.connect(nGain);
            nGain.connect(hp);
            noise.start(t);
            noise.stop(t + 0.05);
            break;
          }

          case 'openHat': {
            const ratios = [205, 304, 370, 523, 540, 800];
            const hp = ctx.createBiquadFilter();
            hp.type = 'highpass';
            hp.frequency.setValueAtTime(Math.min(15000, 6400 * pitchRatio), t);

            const g = ctx.createGain();
            g.gain.setValueAtTime(0.42, t);
            g.gain.exponentialRampToValueAtTime(0.001, t + 0.36);

            hp.connect(g);
            g.connect(out);

            ratios.forEach(freq => {
              const osc = ctx.createOscillator();
              osc.type = 'square';
              osc.frequency.setValueAtTime(freq * pitchRatio, t);
              osc.connect(hp);
              osc.start(t);
              osc.stop(t + 0.38);
            });

            const noise = ctx.createBufferSource();
            noise.buffer = noiseBuffer;
            const nGain = ctx.createGain();
            nGain.gain.setValueAtTime(0.22, t);
            nGain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
            noise.connect(nGain);
            nGain.connect(hp);
            noise.start(t);
            noise.stop(t + 0.28);

            openHatStopFn = (cutTime) => {
              g.gain.cancelScheduledValues(cutTime);
              g.gain.setValueAtTime(Math.max(0.001, g.gain.value), cutTime);
              g.gain.exponentialRampToValueAtTime(0.0001, cutTime + 0.015);
            };
            break;
          }

          case 'crashPerc': {
            // Shimmering crash + crisp perc attack
            const noise = ctx.createBufferSource();
            noise.buffer = noiseBuffer;
            const hp = ctx.createBiquadFilter();
            hp.type = 'highpass';
            hp.frequency.setValueAtTime(Math.min(14000, 4400 * pitchRatio), t);
            const g = ctx.createGain();
            g.gain.setValueAtTime(0.48, t);
            g.gain.exponentialRampToValueAtTime(0.001, t + 0.85);
            noise.connect(hp);
            hp.connect(g);
            g.connect(out);
            noise.start(t);
            noise.stop(t + 0.88);

            const bell = ctx.createOscillator();
            const bg = ctx.createGain();
            bell.type = 'square';
            bell.frequency.setValueAtTime(560 * pitchRatio, t);
            bg.gain.setValueAtTime(0.18, t);
            bg.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
            bell.connect(bg);
            bg.connect(out);
            bell.start(t);
            bell.stop(t + 0.16);
            break;
          }

          case 'tom': {
            const osc = ctx.createOscillator();
            const g = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(185 * pitchRatio, t);
            osc.frequency.exponentialRampToValueAtTime(82 * pitchRatio, t + 0.2);
            g.gain.setValueAtTime(0.9, t);
            g.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
            osc.connect(g);
            g.connect(out);
            osc.start(t);
            osc.stop(t + 0.3);
            break;
          }

          case 'pluck': {
            const osc = ctx.createOscillator();
            const lp = ctx.createBiquadFilter();
            const g = ctx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(261.63 * pitchRatio, t);
            lp.type = 'lowpass';
            lp.frequency.setValueAtTime(2800 * pitchRatio, t);
            lp.frequency.exponentialRampToValueAtTime(320, t + 0.22);
            g.gain.setValueAtTime(0.55, t);
            g.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
            osc.connect(lp);
            lp.connect(g);
            g.connect(out);
            osc.start(t);
            osc.stop(t + 0.3);
            break;
          }
        }
      }

      /* ================= PRECISION LOOKAHEAD SCHEDULER ================= */
      let schedulerTimer = null;
      let nextStepIndex = 0;
      let nextStepBaseTime = 0;
      const visualQueue = [];

      function getStepDuration() {
        return 60 / state.bpm / 4;
      }

      function scheduleStep(stepIndex, stepAudioTime) {
        const activePattern = state.patterns[state.currentPattern];
        for (let i = 0; i < state.channels.length; i++) {
          const ch = state.channels[i];
          const chPat = activePattern[ch.id];
          if (chPat && chPat.steps[stepIndex] && !ch.muted) {
            const vel = chPat.velocity[stepIndex] ?? DEFAULT_VEL;
            const pitch = chPat.pitch[stepIndex] ?? DEFAULT_PITCH;
            triggerSound(ch, stepAudioTime, vel, pitch);
            visualQueue.push({ type: 'activity', channelId: ch.id, time: stepAudioTime });
          }
        }
        visualQueue.push({ type: 'step', step: stepIndex, time: stepAudioTime });
      }

      function schedulerTick() {
        if (!state.isPlaying || !audioCtx) return;
        const lookahead = 0.12; // 120ms buffer safe for iOS Safari
        const stepDur = getStepDuration();

        while (nextStepBaseTime < audioCtx.currentTime + lookahead) {
          const isOdd = nextStepIndex % 2 === 1;
          const swingOffset = isOdd ? (state.swing / 100) * (stepDur * 0.66) : 0;
          scheduleStep(nextStepIndex, nextStepBaseTime + swingOffset);
          nextStepBaseTime += stepDur;
          nextStepIndex = (nextStepIndex + 1) % STEPS_COUNT;
        }
      }

      function animationLoop() {
        if (state.isPlaying && audioCtx) {
          const now = audioCtx.currentTime;
          while (visualQueue.length > 0 && visualQueue[0].time <= now + 0.016) {
            const ev = visualQueue.shift();
            if (ev.type === 'step') {
              updatePlayheadVisual(ev.step);
            } else if (ev.type === 'activity') {
              flashChannelActivity(ev.channelId);
            }
          }
        }
        requestAnimationFrame(animationLoop);
      }
      requestAnimationFrame(animationLoop);

      function startPlayback() {
        const ctx = ensureAudioContext();
        state.isPlaying = true;
        if (nextStepIndex < 0 || nextStepIndex >= STEPS_COUNT) {
          nextStepIndex = 0;
        }
        nextStepBaseTime = ctx.currentTime + 0.03;
        visualQueue.length = 0;
        schedulerTick();
        if (schedulerTimer) clearInterval(schedulerTimer);
        schedulerTimer = setInterval(schedulerTick, 25);
        updateTransportUI();
      }

      function pausePlayback() {
        state.isPlaying = false;
        if (schedulerTimer) {
          clearInterval(schedulerTimer);
          schedulerTimer = null;
        }
        visualQueue.length = 0;
        updateTransportUI();
      }

      function stopPlayback() {
        state.isPlaying = false;
        if (schedulerTimer) {
          clearInterval(schedulerTimer);
          schedulerTimer = null;
        }
        visualQueue.length = 0;
        nextStepIndex = 0;
        state.currentStep = -1;
        updatePlayheadVisual(-1);
        updateTransportUI();
      }

      /* ================= DOM REFERENCES ================= */
      const playBtn = document.getElementById('playBtn');
      const playIcon = document.getElementById('playIcon');
      const playLabel = document.getElementById('playLabel');
      const stopBtn = document.getElementById('stopBtn');
      const bpmDown = document.getElementById('bpmDown');
      const bpmUp = document.getElementById('bpmUp');
      const bpmDrag = document.getElementById('bpmDrag');
      const bpmValue = document.getElementById('bpmValue');
      const patternTabs = document.getElementById('patternTabs');
      const clonePatternBtn = document.getElementById('clonePatternBtn');
      const downloadZipBtn = document.getElementById('downloadZipBtn');
      const channelOptionsBtn = document.getElementById('channelOptionsBtn');
      const addChannelBtn = document.getElementById('addChannelBtn');
      const globalSwingSlider = document.getElementById('globalSwingSlider');
      const globalSwingVal = document.getElementById('globalSwingVal');
      const graphEditorBtn = document.getElementById('graphEditorBtn');
      const layoutToggleBtn = document.getElementById('layoutToggleBtn');
      const channelList = document.getElementById('channelList');
      const playheadLeds = document.getElementById('playheadLeds');
      const statusPatternText = document.getElementById('statusPatternText');
      const statusChannelText = document.getElementById('statusChannelText');
      const statusStepText = document.getElementById('statusStepText');
      const knobHud = document.getElementById('knobHud');
      const modalBackdrop = document.getElementById('modalBackdrop');
      const modalSheet = document.getElementById('modalSheet');

      /* ================= UI HELPERS ================= */
      const activityTimers = new Map();
      function flashChannelActivity(channelId) {
        const dot = document.querySelector(`.activity-dot[data-channel="${channelId}"]`);
        if (!dot) return;
        dot.classList.add('lit');
        if (activityTimers.has(channelId)) clearTimeout(activityTimers.get(channelId));
        activityTimers.set(channelId, setTimeout(() => dot.classList.remove('lit'), 95));
      }

      function updatePlayheadVisual(step) {
        state.currentStep = step;
        statusStepText.textContent = step >= 0 ? `Step ${step + 1} / 16` : 'Step -- / 16';

        const bottomLeds = playheadLeds.querySelectorAll('.playhead-led');
        bottomLeds.forEach((el, idx) => {
          el.classList.toggle('current', idx === step);
          el.classList.toggle('beat-start', idx === step && idx % 4 === 0);
        });

        channelList.querySelectorAll('.step-btn').forEach(btn => {
          btn.classList.toggle('is-playing', Number(btn.dataset.step) === step);
        });

        channelList.querySelectorAll('.graph-bar-col').forEach(col => {
          col.classList.toggle('is-playing', Number(col.dataset.step) === step);
        });
      }

      function updateTransportUI() {
        playBtn.classList.toggle('playing', state.isPlaying);
        playLabel.textContent = state.isPlaying ? 'Pause' : 'Play';
        if (state.isPlaying) {
          playIcon.innerHTML = '<rect x="5" y="4" width="5" height="16" rx="1"></rect><rect x="14" y="4" width="5" height="16" rx="1"></rect>';
        } else {
          playIcon.innerHTML = '<polygon points="6,4 20,12 6,20"></polygon>';
        }
        bpmValue.textContent = state.bpm;
        globalSwingSlider.value = state.swing;
        globalSwingVal.textContent = `${state.swing}%`;
        graphEditorBtn.classList.toggle('active', state.graphEditorOpen);
        graphEditorBtn.setAttribute('aria-pressed', String(state.graphEditorOpen));
        statusPatternText.textContent = `Pattern ${state.currentPattern + 1}`;
        const selCh = state.channels.find(c => c.id === state.selectedChannelId);
        statusChannelText.textContent = selCh ? selCh.name : '';
      }

      function showHud(text, x, y) {
        knobHud.textContent = text;
        knobHud.style.left = Math.max(52, Math.min(window.innerWidth - 52, x)) + 'px';
        knobHud.style.top = Math.max(42, y) + 'px';
        knobHud.classList.add('visible');
      }

      function hideHud() {
        knobHud.classList.remove('visible');
      }

      function buildKnobSvg(normalizedVal, isBipolar) {
        const minAngle = -135;
        const maxAngle = 135;
        const angle = isBipolar
          ? normalizedVal * 135
          : minAngle + normalizedVal * (maxAngle - minAngle);

        const cx = 15, cy = 15, r = 11.5;
        function polar(deg, radius) {
          const rad = ((deg - 90) * Math.PI) / 180;
          return { x: cx + radius * Math.cos(rad), y: cy + radius * Math.sin(rad) };
        }
        function arcPath(startDeg, endDeg) {
          if (Math.abs(endDeg - startDeg) < 0.5) return '';
          const s = polar(startDeg, r);
          const e = polar(endDeg, r);
          const large = Math.abs(endDeg - startDeg) > 180 ? 1 : 0;
          const sweep = endDeg > startDeg ? 1 : 0;
          return `M ${s.x.toFixed(2)} ${s.y.toFixed(2)} A ${r} ${r} 0 ${large} ${sweep} ${e.x.toFixed(2)} ${e.y.toFixed(2)}`;
        }

        const trackArc = arcPath(minAngle, maxAngle);
        const valueArc = isBipolar ? arcPath(0, angle) : arcPath(minAngle, angle);
        const pointerEnd = polar(angle, 8.5);
        const pointerStart = polar(angle, 2.5);
        const activeColor = isBipolar ? '#6bb8ff' : '#ff8c28';

        return `
          <svg class="knob-svg" viewBox="0 0 30 30" aria-hidden="true">
            <path d="${trackArc}" fill="none" stroke="#15181c" stroke-width="2.6" stroke-linecap="round"/>
            ${valueArc ? `<path d="${valueArc}" fill="none" stroke="${activeColor}" stroke-width="2.6" stroke-linecap="round"/>` : ''}
            <circle cx="${cx}" cy="${cy}" r="8.2" fill="#2c3239" stroke="#131619" stroke-width="1.2"/>
            <line x1="${pointerStart.x.toFixed(2)}" y1="${pointerStart.y.toFixed(2)}" x2="${pointerEnd.x.toFixed(2)}" y2="${pointerEnd.y.toFixed(2)}" stroke="#eef2f6" stroke-width="2" stroke-linecap="round"/>
          </svg>
        `;
      }

      /* ================= RENDERING ================= */
      function patternHasSteps(patIdx) {
        const pat = state.patterns[patIdx];
        return Object.values(pat).some(chPat => chPat && chPat.steps.some(Boolean));
      }

      function renderPatternTabs() {
        patternTabs.innerHTML = '';
        const prefix = document.createElement('span');
        prefix.className = 'pattern-prefix';
        prefix.textContent = 'PAT';
        patternTabs.appendChild(prefix);

        for (let i = 0; i < PATTERN_COUNT; i++) {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'pattern-tab' + (i === state.currentPattern ? ' active' : '');
          btn.setAttribute('role', 'tab');
          btn.setAttribute('aria-selected', String(i === state.currentPattern));
          btn.setAttribute('aria-label', `Pattern ${i + 1}`);
          const hasData = patternHasSteps(i);
          btn.innerHTML = `<span>${i + 1}</span>${hasData ? '<span class="pat-dot" aria-hidden="true"></span>' : ''}`;
          btn.addEventListener('click', () => {
            state.currentPattern = i;
            renderPatternTabs();
            renderChannelList();
            updateTransportUI();
          });
          patternTabs.appendChild(btn);
        }
      }

      function renderPlayheadRow() {
        playheadLeds.innerHTML = '';
        for (let g = 0; g < 4; g++) {
          const grp = document.createElement('div');
          grp.className = 'playhead-group';
          for (let s = 0; s < 4; s++) {
            const led = document.createElement('div');
            led.className = 'playhead-led';
            grp.appendChild(led);
          }
          playheadLeds.appendChild(grp);
        }
      }

      let paintState = { active: false, targetVal: true, channelId: null };
      let graphPaintState = { active: false, channelId: null };

      function applyGraphBarVisual(col, chPat, stepIdx) {
        const fill = col.querySelector('.graph-bar-fill');
        const isActive = chPat.steps[stepIdx];
        col.classList.toggle('inactive-step', !isActive);

        if (state.graphMode === 'velocity') {
          const vel = chPat.velocity[stepIdx];
          const pct = Math.max(4, Math.round(vel * 100));
          fill.style.background = isActive
            ? 'linear-gradient(180deg, #ffaa52 0%, #ff7b1c 100%)'
            : '#8d6442';
          fill.style.bottom = '2px';
          fill.style.top = `${100 - pct}%`;
        } else {
          const pitch = chPat.pitch[stepIdx]; // -12 to +12
          const halfPct = (Math.abs(pitch) / 12) * 48;
          fill.style.background = isActive
            ? (pitch >= 0 ? 'linear-gradient(180deg, #86cbff 0%, #4599eb 100%)' : 'linear-gradient(180deg, #69e854 0%, #3fb52d 100%)')
            : '#4d6f8c';
          if (pitch >= 0) {
            fill.style.bottom = '50%';
            fill.style.top = `${50 - Math.max(3, halfPct)}%`;
          } else {
            fill.style.top = '50%';
            fill.style.bottom = `${50 - Math.max(3, halfPct)}%`;
          }
        }
      }

      function buildGraphEditorElement(ch, chPat) {
        const panel = document.createElement('div');
        panel.className = 'graph-editor-panel';
        panel.dataset.channelId = ch.id;

        const sidebar = document.createElement('div');
        sidebar.className = 'graph-sidebar';
        sidebar.innerHTML = `
          <div class="graph-mode-tabs">
            <button type="button" class="graph-tab ${state.graphMode === 'velocity' ? 'active' : ''}" data-mode="velocity">Velocity</button>
            <button type="button" class="graph-tab ${state.graphMode === 'pitch' ? 'active' : ''}" data-mode="pitch">Pitch</button>
          </div>
          <div class="graph-meta-row">
            <span>${escapeHtml(ch.name)} · ${state.graphMode === 'velocity' ? '0–100%' : '±12 st'}</span>
            <button type="button" class="graph-reset-btn" id="graphResetBtn">Reset</button>
          </div>
        `;

        sidebar.querySelectorAll('.graph-tab').forEach(tab => {
          tab.addEventListener('click', () => {
            state.graphMode = tab.dataset.mode;
            renderChannelList();
          });
        });

        sidebar.querySelector('#graphResetBtn').addEventListener('click', () => {
          if (state.graphMode === 'velocity') {
            chPat.velocity.fill(DEFAULT_VEL);
          } else {
            chPat.pitch.fill(DEFAULT_PITCH);
          }
          renderChannelList();
        });

        const barsWrap = document.createElement('div');
        barsWrap.className = 'graph-bars-wrap';

        for (let g = 0; g < 4; g++) {
          const grp = document.createElement('div');
          grp.className = 'graph-group';
          const isGroupB = g % 2 === 1;

          for (let s = 0; s < 4; s++) {
            const stepIdx = g * 4 + s;
            const col = document.createElement('div');
            col.className = `graph-bar-col${isGroupB ? ' group-b' : ''}`;
            col.dataset.step = String(stepIdx);
            col.dataset.channel = ch.id;
            col.innerHTML = `
              ${state.graphMode === 'pitch' ? '<div class="graph-zero-line"></div>' : ''}
              <div class="graph-bar-fill"></div>
              <span class="graph-bar-num">${stepIdx + 1}</span>
            `;
            applyGraphBarVisual(col, chPat, stepIdx);

            const updateColFromClientY = (clientY, rect) => {
              const relY = Math.max(0, Math.min(1, 1 - (clientY - rect.top) / rect.height));
              if (state.graphMode === 'velocity') {
                chPat.velocity[stepIdx] = Math.max(0.05, Math.min(1, relY));
                showHud(`Step ${stepIdx + 1} Vel: ${Math.round(chPat.velocity[stepIdx] * 100)}%`, rect.left + rect.width / 2, rect.top);
              } else {
                const rawSemi = Math.round((relY * 2 - 1) * 12);
                chPat.pitch[stepIdx] = Math.max(-12, Math.min(12, rawSemi));
                const sign = chPat.pitch[stepIdx] > 0 ? '+' : '';
                showHud(`Step ${stepIdx + 1} Pitch: ${sign}${chPat.pitch[stepIdx]} st`, rect.left + rect.width / 2, rect.top);
              }
              applyGraphBarVisual(col, chPat, stepIdx);
            };

            col.addEventListener('pointerdown', (e) => {
              e.preventDefault();
              graphPaintState = { active: true, channelId: ch.id };
              const rect = col.getBoundingClientRect();
              updateColFromClientY(e.clientY, rect);
            });

            grp.appendChild(col);
          }
          barsWrap.appendChild(grp);
        }

        panel.appendChild(sidebar);
        panel.appendChild(barsWrap);
        return panel;
      }

      function renderChannelList() {
        channelList.innerHTML = '';
        const activePat = state.patterns[state.currentPattern];

        state.channels.forEach(ch => {
          if (!activePat[ch.id]) {
            activePat[ch.id] = makeChannelPatternData();
          }
          const chPat = activePat[ch.id];
          const isSelected = ch.id === state.selectedChannelId;

          const block = document.createElement('div');
          block.className = 'channel-block';

          const row = document.createElement('div');
          row.className = 'channel-row' + (isSelected ? ' selected' : '');
          row.dataset.channelId = ch.id;

          const controls = document.createElement('div');
          controls.className = 'channel-controls-strip';

          // 1. Mute LED
          const muteBtn = document.createElement('button');
          muteBtn.type = 'button';
          muteBtn.className = 'mute-btn' + (ch.muted ? '' : ' unmuted');
          muteBtn.setAttribute('aria-label', `Mute ${ch.name}`);
          muteBtn.setAttribute('aria-pressed', String(!ch.muted));
          muteBtn.innerHTML = '<span class="mute-led"></span>';
          muteBtn.addEventListener('click', () => {
            ch.muted = !ch.muted;
            muteBtn.classList.toggle('unmuted', !ch.muted);
            muteBtn.setAttribute('aria-pressed', String(!ch.muted));
          });
          controls.appendChild(muteBtn);

          // 2. Pan Knob
          const panWrap = document.createElement('div');
          panWrap.className = 'knob-wrap';
          panWrap.setAttribute('aria-label', `${ch.name} Pan`);
          panWrap.innerHTML = `<span class="knob-slot">${buildKnobSvg(ch.pan, true)}</span><span class="knob-sublabel">PAN</span>`;
          const panSlot = panWrap.querySelector('.knob-slot');
          attachKnobGesture(panWrap, () => ch.pan, (val) => {
            ch.pan = Math.max(-1, Math.min(1, val));
            if (Math.abs(ch.pan) < 0.04) ch.pan = 0;
            panSlot.innerHTML = buildKnobSvg(ch.pan, true);
            const pct = Math.round(ch.pan * 100);
            return pct === 0 ? 'Pan: Center' : (pct < 0 ? `Pan: ${Math.abs(pct)}% L` : `Pan: ${pct}% R`);
          }, 0, true);
          controls.appendChild(panWrap);

          // 3. Volume Knob
          const volWrap = document.createElement('div');
          volWrap.className = 'knob-wrap';
          volWrap.setAttribute('aria-label', `${ch.name} Volume`);
          volWrap.innerHTML = `<span class="knob-slot">${buildKnobSvg(ch.volume, false)}</span><span class="knob-sublabel">VOL</span>`;
          const volSlot = volWrap.querySelector('.knob-slot');
          attachKnobGesture(volWrap, () => ch.volume, (val) => {
            ch.volume = Math.max(0, Math.min(1, val));
            volSlot.innerHTML = buildKnobSvg(ch.volume, false);
            return `Vol: ${Math.round(ch.volume * 100)}%`;
          }, 0.8, false);
          controls.appendChild(volWrap);

          // 4. Rectangular Channel Button (Instant Preview + Select)
          const chBtnWrap = document.createElement('div');
          chBtnWrap.className = 'channel-btn-wrap';

          const chBtn = document.createElement('button');
          chBtn.type = 'button';
          chBtn.className = 'channel-btn';
          chBtn.style.background = `linear-gradient(180deg, ${adjustHex(ch.color, 18)} 0%, ${ch.color} 100%)`;
          chBtn.innerHTML = `<span class="channel-name">${escapeHtml(ch.name)}</span><span class="activity-dot" data-channel="${ch.id}"></span>`;
          chBtn.addEventListener('pointerdown', (e) => {
            if (e.button && e.button !== 0) return;
            const prevSel = state.selectedChannelId;
            state.selectedChannelId = ch.id;
            triggerSound(ch, undefined, DEFAULT_VEL, 0);
            flashChannelActivity(ch.id);
            updateTransportUI();

            if (state.graphEditorOpen && prevSel !== ch.id) {
              renderChannelList();
            } else {
              document.querySelectorAll('.channel-row').forEach(r => r.classList.toggle('selected', r.dataset.channelId === ch.id));
              chBtn.classList.add('triggered');
              setTimeout(() => chBtn.classList.remove('triggered'), 110);
            }
          });

          chBtnWrap.appendChild(chBtn);
          controls.appendChild(chBtnWrap);

          // 5. Green Channel Selector Pill
          const selPill = document.createElement('button');
          selPill.type = 'button';
          selPill.className = 'channel-selector-pill';
          selPill.setAttribute('aria-label', `Select ${ch.name}`);
          selPill.addEventListener('click', () => {
            state.selectedChannelId = ch.id;
            renderChannelList();
            updateTransportUI();
          });
          controls.appendChild(selPill);

          row.appendChild(controls);

          // 6. 16-Step Sequencer Grid
          const seqArea = document.createElement('div');
          seqArea.className = 'sequencer-area';

          const stepsGrid = document.createElement('div');
          stepsGrid.className = 'steps-grid';

          for (let g = 0; g < 4; g++) {
            const groupEl = document.createElement('div');
            groupEl.className = 'step-group';
            const groupClass = g % 2 === 0 ? 'group-a' : 'group-b';

            for (let s = 0; s < 4; s++) {
              const stepIdx = g * 4 + s;
              const stepBtn = document.createElement('button');
              stepBtn.type = 'button';
              stepBtn.className = `step-btn ${groupClass}${chPat.steps[stepIdx] ? ' active' : ''}`;
              stepBtn.dataset.step = String(stepIdx);
              stepBtn.dataset.channel = ch.id;
              stepBtn.setAttribute('aria-label', `${ch.name} Step ${stepIdx + 1}`);
              stepBtn.setAttribute('aria-pressed', String(chPat.steps[stepIdx]));

              stepBtn.addEventListener('pointerdown', (e) => {
                e.preventDefault();
                const nextVal = !chPat.steps[stepIdx];
                chPat.steps[stepIdx] = nextVal;
                paintState = { active: true, targetVal: nextVal, channelId: ch.id };
                stepBtn.classList.toggle('active', nextVal);
                stepBtn.setAttribute('aria-pressed', String(nextVal));
                renderPatternTabs();

                // Update inline graph bar opacity if Graph Editor is open for this channel
                if (state.graphEditorOpen && state.selectedChannelId === ch.id) {
                  const col = block.querySelector(`.graph-bar-col[data-step="${stepIdx}"]`);
                  if (col) applyGraphBarVisual(col, chPat, stepIdx);
                }

                if (stepBtn.releasePointerCapture && e.pointerId !== undefined) {
                  try { stepBtn.releasePointerCapture(e.pointerId); } catch (_) {}
                }
              });

              groupEl.appendChild(stepBtn);
            }
            stepsGrid.appendChild(groupEl);
          }

          seqArea.appendChild(stepsGrid);
          row.appendChild(seqArea);
          block.appendChild(row);

          // Inline Graph Editor directly underneath selected channel
          if (state.graphEditorOpen && isSelected) {
            block.appendChild(buildGraphEditorElement(ch, chPat));
          }

          channelList.appendChild(block);
        });
      }

      /* ================= GLOBAL POINTER MOVE FOR TOUCH PAINTING ================= */
      window.addEventListener('pointermove', (e) => {
        if (paintState.active) {
          const el = document.elementFromPoint(e.clientX, e.clientY);
          if (el && el.classList && el.classList.contains('step-btn')) {
            const chId = el.dataset.channel;
            const stepIdx = Number(el.dataset.step);
            if (chId === paintState.channelId) {
              const chPat = state.patterns[state.currentPattern][chId];
              if (chPat && chPat.steps[stepIdx] !== paintState.targetVal) {
                chPat.steps[stepIdx] = paintState.targetVal;
                el.classList.toggle('active', paintState.targetVal);
                el.setAttribute('aria-pressed', String(paintState.targetVal));
                if (state.graphEditorOpen && state.selectedChannelId === chId) {
                  const col = document.querySelector(`.graph-bar-col[data-channel="${chId}"][data-step="${stepIdx}"]`);
                  if (col) applyGraphBarVisual(col, chPat, stepIdx);
                }
              }
            }
          }
        }

        if (graphPaintState.active) {
          const el = document.elementFromPoint(e.clientX, e.clientY);
          const col = el ? el.closest('.graph-bar-col') : null;
          if (col && col.dataset.channel === graphPaintState.channelId) {
            const stepIdx = Number(col.dataset.step);
            const chPat = state.patterns[state.currentPattern][graphPaintState.channelId];
            if (chPat) {
              const rect = col.getBoundingClientRect();
              const relY = Math.max(0, Math.min(1, 1 - (e.clientY - rect.top) / rect.height));
              if (state.graphMode === 'velocity') {
                chPat.velocity[stepIdx] = Math.max(0.05, Math.min(1, relY));
                showHud(`Step ${stepIdx + 1} Vel: ${Math.round(chPat.velocity[stepIdx] * 100)}%`, rect.left + rect.width / 2, rect.top);
              } else {
                const rawSemi = Math.round((relY * 2 - 1) * 12);
                chPat.pitch[stepIdx] = Math.max(-12, Math.min(12, rawSemi));
                const sign = chPat.pitch[stepIdx] > 0 ? '+' : '';
                showHud(`Step ${stepIdx + 1} Pitch: ${sign}${chPat.pitch[stepIdx]} st`, rect.left + rect.width / 2, rect.top);
              }
              applyGraphBarVisual(col, chPat, stepIdx);
            }
          }
        }
      }, { passive: true });

      window.addEventListener('pointerup', () => {
        if (paintState.active) {
          paintState.active = false;
          renderPatternTabs();
        }
        if (graphPaintState.active) {
          graphPaintState.active = false;
          hideHud();
        }
      });

      window.addEventListener('pointercancel', () => {
        paintState.active = false;
        graphPaintState.active = false;
        hideHud();
      });

      /* ================= TOUCH KNOBS & BPM GESTURES ================= */
      function attachKnobGesture(el, getVal, setAndFormat, defaultVal, isBipolar) {
        let lastTap = 0;
        el.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          const now = Date.now();
          if (now - lastTap < 280) {
            const hudText = setAndFormat(defaultVal);
            const rect = el.getBoundingClientRect();
            showHud(hudText, rect.left + rect.width / 2, rect.top);
            setTimeout(hideHud, 650);
            lastTap = 0;
            return;
          }
          lastTap = now;

          const startY = e.clientY;
          const startX = e.clientX;
          const startVal = getVal();
          const sensitivity = isBipolar ? 105 : 130;
          el.setPointerCapture(e.pointerId);

          const rect = el.getBoundingClientRect();
          showHud(setAndFormat(startVal), rect.left + rect.width / 2, rect.top);

          const onMove = (ev) => {
            const delta = (startY - ev.clientY) + (ev.clientX - startX) * 0.5;
            const span = isBipolar ? 2 : 1;
            const txt = setAndFormat(startVal + (delta / sensitivity) * span);
            showHud(txt, rect.left + rect.width / 2, rect.top);
          };

          const onUp = () => {
            hideHud();
            el.removeEventListener('pointermove', onMove);
            el.removeEventListener('pointerup', onUp);
            el.removeEventListener('pointercancel', onUp);
          };

          el.addEventListener('pointermove', onMove);
          el.addEventListener('pointerup', onUp);
          el.addEventListener('pointercancel', onUp);
        });
      }

      bpmDrag.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        const startY = e.clientY;
        const startBpm = state.bpm;
        bpmDrag.setPointerCapture(e.pointerId);
        const rect = bpmDrag.getBoundingClientRect();
        showHud(`${state.bpm} BPM`, rect.left + rect.width / 2, rect.bottom + 42);

        const onMove = (ev) => {
          const dy = startY - ev.clientY;
          const next = Math.max(60, Math.min(200, Math.round(startBpm + dy * 0.45)));
          state.bpm = next;
          bpmValue.textContent = next;
          showHud(`${next} BPM`, rect.left + rect.width / 2, rect.bottom + 42);
        };
        const onUp = () => {
          hideHud();
          bpmDrag.removeEventListener('pointermove', onMove);
          bpmDrag.removeEventListener('pointerup', onUp);
          bpmDrag.removeEventListener('pointercancel', onUp);
        };
        bpmDrag.addEventListener('pointermove', onMove);
        bpmDrag.addEventListener('pointerup', onUp);
        bpmDrag.addEventListener('pointercancel', onUp);
      });

      bpmDown.addEventListener('click', () => {
        state.bpm = Math.max(60, state.bpm - 1);
        bpmValue.textContent = state.bpm;
      });

      bpmUp.addEventListener('click', () => {
        state.bpm = Math.min(200, state.bpm + 1);
        bpmValue.textContent = state.bpm;
      });

      /* ================= MODALS: CHANNEL OPTIONS, ADD, CLONE PATTERN ================= */
      function closeModal() {
        modalBackdrop.classList.remove('open');
        modalSheet.innerHTML = '';
      }

      modalBackdrop.addEventListener('click', (e) => {
        if (e.target === modalBackdrop) closeModal();
      });

      function openChannelOptionsModal() {
        const chIndex = state.channels.findIndex(c => c.id === state.selectedChannelId);
        const ch = state.channels[chIndex >= 0 ? chIndex : 0];
        if (!ch) return;
        const chPat = state.patterns[state.currentPattern][ch.id];

        modalSheet.innerHTML = `
          <div class="sheet-header">
            <span class="sheet-title">Channel Options · ${escapeHtml(ch.name)}</span>
            <button type="button" class="sheet-close" id="closeModalBtn" aria-label="Close">✕</button>
          </div>

          <div class="sheet-section-label">Quick Step Fill (FL Studio)</div>
          <div class="menu-actions-grid">
            <button type="button" class="menu-action-btn" id="optFill2">
              <span>▤</span><span>Fill each 2 steps</span>
            </button>
            <button type="button" class="menu-action-btn" id="optFill4">
              <span>▥</span><span>Fill each 4 steps</span>
            </button>
            <button type="button" class="menu-action-btn" id="optClearRow">
              <span>⌫</span><span>Clear Steps</span>
            </button>
            <button type="button" class="menu-action-btn" id="optAddCh">
              <span>＋</span><span>Add Channel</span>
            </button>
          </div>

          <div class="sheet-section-label">Channel Management</div>
          <div class="menu-actions-grid">
            <button type="button" class="menu-action-btn" id="optCloneCh">
              <span>⧉</span><span>Clone Channel</span>
            </button>
            <button type="button" class="menu-action-btn danger" id="optDeleteCh" ${state.channels.length <= 1 ? 'disabled' : ''}>
              <span>✕</span><span>Delete Channel</span>
            </button>
            <button type="button" class="menu-action-btn" id="optMoveUp" ${chIndex === 0 ? 'disabled' : ''}>
              <span>↑</span><span>Move Up</span>
            </button>
            <button type="button" class="menu-action-btn" id="optMoveDown" ${chIndex === state.channels.length - 1 ? 'disabled' : ''}>
              <span>↓</span><span>Move Down</span>
            </button>
          </div>

          <div class="sheet-section-label">Channel Color</div>
          <div class="color-swatches" id="colorSwatches"></div>
        `;

        document.getElementById('closeModalBtn').addEventListener('click', closeModal);

        document.getElementById('optFill2').addEventListener('click', () => {
          for (let i = 0; i < STEPS_COUNT; i++) {
            chPat.steps[i] = (i % 2 === 0);
          }
          closeModal();
          renderChannelList();
          renderPatternTabs();
        });

        document.getElementById('optFill4').addEventListener('click', () => {
          for (let i = 0; i < STEPS_COUNT; i++) {
            chPat.steps[i] = (i % 4 === 0);
          }
          closeModal();
          renderChannelList();
          renderPatternTabs();
        });

        document.getElementById('optClearRow').addEventListener('click', () => {
          chPat.steps.fill(false);
          closeModal();
          renderChannelList();
          renderPatternTabs();
        });

        document.getElementById('optAddCh').addEventListener('click', openAddChannelModal);

        document.getElementById('optCloneCh').addEventListener('click', () => {
          const clone = { ...ch, id: makeId(), name: ch.name + ' (2)' };
          state.channels.splice(chIndex + 1, 0, clone);
          state.patterns.forEach(pat => {
            const src = pat[ch.id] || makeChannelPatternData();
            pat[clone.id] = {
              steps: [...src.steps],
              velocity: [...src.velocity],
              pitch: [...src.pitch]
            };
          });
          state.selectedChannelId = clone.id;
          closeModal();
          renderChannelList();
          renderPatternTabs();
          updateTransportUI();
        });

        document.getElementById('optDeleteCh').addEventListener('click', () => {
          if (state.channels.length <= 1) return;
          state.channels.splice(chIndex, 1);
          state.patterns.forEach(pat => delete pat[ch.id]);
          state.selectedChannelId = state.channels[Math.max(0, chIndex - 1)].id;
          closeModal();
          renderChannelList();
          renderPatternTabs();
          updateTransportUI();
        });

        document.getElementById('optMoveUp').addEventListener('click', () => {
          if (chIndex > 0) {
            [state.channels[chIndex - 1], state.channels[chIndex]] = [state.channels[chIndex], state.channels[chIndex - 1]];
            renderChannelList();
            openChannelOptionsModal();
          }
        });

        document.getElementById('optMoveDown').addEventListener('click', () => {
          if (chIndex < state.channels.length - 1) {
            [state.channels[chIndex + 1], state.channels[chIndex]] = [state.channels[chIndex], state.channels[chIndex + 1]];
            renderChannelList();
            openChannelOptionsModal();
          }
        });

        const swatches = document.getElementById('colorSwatches');
        CHANNEL_COLORS.forEach(hex => {
          const sw = document.createElement('button');
          sw.type = 'button';
          sw.className = 'color-swatch' + (ch.color.toLowerCase() === hex.toLowerCase() ? ' active' : '');
          sw.style.background = hex;
          sw.setAttribute('aria-label', `Color ${hex}`);
          sw.addEventListener('click', () => {
            ch.color = hex;
            renderChannelList();
            swatches.querySelectorAll('.color-swatch').forEach(s => s.classList.remove('active'));
            sw.classList.add('active');
          });
          swatches.appendChild(sw);
        });

        modalBackdrop.classList.add('open');
      }

      function openAddChannelModal() {
        modalSheet.innerHTML = `
          <div class="sheet-header">
            <span class="sheet-title">Add Channel Instrument</span>
            <button type="button" class="sheet-close" id="closeModalBtn" aria-label="Close">✕</button>
          </div>
          <div class="sheet-section-label">Select Drum or Synth Instrument</div>
          <div class="preset-list" id="presetList"></div>
        `;
        document.getElementById('closeModalBtn').addEventListener('click', closeModal);
        const list = document.getElementById('presetList');

        SYNTH_PRESETS.forEach(preset => {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'menu-action-btn';
          btn.innerHTML = `<span style="width:12px;height:12px;border-radius:3px;background:${preset.color};flex-shrink:0;"></span><span>${preset.name}</span>`;
          btn.addEventListener('click', () => {
            const newCh = {
              id: makeId(),
              name: preset.name,
              type: preset.type,
              color: preset.color,
              pan: 0,
              volume: 0.80,
              muted: false
            };
            state.channels.push(newCh);
            state.patterns.forEach(pat => {
              pat[newCh.id] = makeChannelPatternData();
            });
            state.selectedChannelId = newCh.id;
            triggerSound(newCh);
            closeModal();
            renderChannelList();
            updateTransportUI();
          });
          list.appendChild(btn);
        });
        modalBackdrop.classList.add('open');
      }

      function openClonePatternModal() {
        const src = state.currentPattern;
        modalSheet.innerHTML = `
          <div class="sheet-header">
            <span class="sheet-title">Clone Pattern ${src + 1} To...</span>
            <button type="button" class="sheet-close" id="closeModalBtn" aria-label="Close">✕</button>
          </div>
          <div class="sheet-section-label">Choose destination pattern (copies steps, velocity &amp; pitch)</div>
          <div class="menu-actions-grid" id="cloneTargets"></div>
          <div class="sheet-section-label">Pattern Reset</div>
          <button type="button" class="menu-action-btn danger" id="clearPatternBtn">
            <span>⌫</span><span>Clear Entire Pattern ${src + 1}</span>
          </button>
        `;
        document.getElementById('closeModalBtn').addEventListener('click', closeModal);
        const targets = document.getElementById('cloneTargets');

        for (let i = 0; i < PATTERN_COUNT; i++) {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'menu-action-btn';
          if (i === src) btn.disabled = true;
          btn.innerHTML = `<span>⧉</span><span>Pattern ${i + 1}${i === src ? ' (Now)' : ''}</span>`;
          btn.addEventListener('click', () => {
            const cloned = {};
            state.channels.forEach(ch => {
              const s = state.patterns[src][ch.id] || makeChannelPatternData();
              cloned[ch.id] = {
                steps: [...s.steps],
                velocity: [...s.velocity],
                pitch: [...s.pitch]
              };
            });
            state.patterns[i] = cloned;
            state.currentPattern = i;
            closeModal();
            renderPatternTabs();
            renderChannelList();
            updateTransportUI();
          });
          targets.appendChild(btn);
        }

        document.getElementById('clearPatternBtn').addEventListener('click', () => {
          state.channels.forEach(ch => {
            state.patterns[src][ch.id] = makeChannelPatternData();
          });
          closeModal();
          renderPatternTabs();
          renderChannelList();
        });

        modalBackdrop.classList.add('open');
      }

      /* ================= UTILITIES ================= */
      function adjustHex(hex, amount) {
        const clean = hex.replace('#', '');
        const num = parseInt(clean, 16);
        const r = Math.max(0, Math.min(255, ((num >> 16) & 255) + amount));
        const g = Math.max(0, Math.min(255, ((num >> 8) & 255) + amount));
        const b = Math.max(0, Math.min(255, (num & 255) + amount));
        return `rgb(${r}, ${g}, ${b})`;
      }

      function escapeHtml(str) {
        return String(str)
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;');
      }

      /* ================= ZIP PROJECT EXPORT (JSZIP + iOS SAFARI) ================= */
      function buildExportedHtml() {
        const shellClone = document.querySelector('.app-shell').cloneNode(true);
        const clonePatternTabs = shellClone.querySelector('#patternTabs');
        const cloneChannelList = shellClone.querySelector('#channelList');
        const clonePlayheadLeds = shellClone.querySelector('#playheadLeds');
        const clonePlayBtn = shellClone.querySelector('#playBtn');
        const clonePlayLabel = shellClone.querySelector('#playLabel');
        const clonePlayIcon = shellClone.querySelector('#playIcon');
        const cloneGraphBtn = shellClone.querySelector('#graphEditorBtn');
        const cloneStatusStep = shellClone.querySelector('#statusStepText');
        const cloneStatusPat = shellClone.querySelector('#statusPatternText');
        const cloneStatusCh = shellClone.querySelector('#statusChannelText');
        const cloneBpmVal = shellClone.querySelector('#bpmValue');
        const cloneSwingSlider = shellClone.querySelector('#globalSwingSlider');
        const cloneSwingVal = shellClone.querySelector('#globalSwingVal');

        if (clonePatternTabs) clonePatternTabs.innerHTML = '';
        if (cloneChannelList) cloneChannelList.innerHTML = '';
        if (clonePlayheadLeds) clonePlayheadLeds.innerHTML = '';
        if (clonePlayBtn) clonePlayBtn.classList.remove('playing');
        if (clonePlayLabel) clonePlayLabel.textContent = 'Play';
        if (clonePlayIcon) clonePlayIcon.innerHTML = '<polygon points="6,4 20,12 6,20"></polygon>';
        if (cloneGraphBtn) {
          cloneGraphBtn.classList.remove('active');
          cloneGraphBtn.setAttribute('aria-pressed', 'false');
        }
        if (cloneStatusPat) cloneStatusPat.textContent = 'Pattern 1';
        if (cloneStatusCh) cloneStatusCh.textContent = 'Kick';
        if (cloneStatusStep) cloneStatusStep.textContent = 'Step -- / 16';
        if (cloneBpmVal) cloneBpmVal.textContent = '132';
        if (cloneSwingSlider) cloneSwingSlider.setAttribute('value', '18');
        if (cloneSwingVal) cloneSwingVal.textContent = '18%';

        const cleanBodyHtml = shellClone.outerHTML;
        return [
          '<!doctype html>',
          '<html lang="en">',
          '<head>',
          '  <meta charset="UTF-8" />',
          '  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />',
          '  <meta name="apple-mobile-web-app-capable" content="yes" />',
          '  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />',
          '  <title>FL Studio Channel Rack &amp; Step Sequencer</title>',
          '  <meta name="description" content="Precision FL Studio Channel Rack, Step Sequencer &amp; Graph Editor web synthesizer optimized for iPhone touch controls." />',
          '  <link rel="stylesheet" href="style.css" />',
          '  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"><\/script>',
          '</head>',
          '<body>',
          '  ' + cleanBodyHtml,
          '',
          '  <!-- Floating Value HUD -->',
          '  <div id="knobHud" class="knob-hud" role="status" aria-live="polite"></div>',
          '',
          '  <!-- Quick Options / Add Channel / Clone Pattern Sheet -->',
          '  <div id="modalBackdrop" class="modal-backdrop" role="dialog" aria-modal="true">',
          '    <div id="modalSheet" class="menu-sheet"></div>',
          '  </div>',
          '',
          '  <script src="app.js"><\/script>',
          '</body>',
          '</html>',
          ''
        ].join('\n');
      }

      function buildReadmeContent() {
        return [
          '# FL Studio Channel Rack & Step Sequencer',
          '',
          'A standalone Web Audio API drum machine, 16-step sequencer, and inline Graph Editor inspired by FL Studio and designed for touch controls on iPhone Safari and desktop browsers.',
          '',
          '## Included Files',
          '- `index.html` — Application layout and transport/rack UI structure.',
          '- `style.css` — Dark FL Studio theme, responsive Portrait/Landscape touch styles, and step/graph editor styling.',
          '- `app.js` — Web Audio API synthesis engine (8 core instruments + extras), Lookahead Scheduler, Graph Editor (Velocity & Pitch), Pattern 1–8 management, and ZIP exporter.',
          '- `README.md` — Setup and usage guide.',
          '',
          '## How to Run',
          '1. Extract `fl-studio-channel-rack.zip` into a folder.',
          '2. Open `index.html` directly in Safari, Chrome, or Edge — or serve the folder via any local static web server:',
          '   - `npx serve .`',
          '   - or `python3 -m http.server 8080`',
          '',
          '## Features',
          '- **8 Synthesized Instruments (Zero external audio files):** Kick, 808 Sub, Snare, Clap, Rimshot, Closed Hat, Open Hat, Crash / Perc (plus Add Channel presets).',
          '- **Patterns 1–8 + Clone Pattern:** Switch across 8 patterns and clone any pattern including steps, velocity, and pitch.',
          '- **Graph Editor:** Edit per-step Velocity (0–100%) and Pitch (±12 semitones) directly underneath the selected channel.',
          '- **Touch Controls:** Drag Pan/Volume knobs and BPM vertically, swipe across steps to paint, and adjust Global Swing (0–100%).',
          '- **Quick Channel Options:** Fill each 2 steps, Fill each 4 steps, Clear, Clone, Reorder, Delete, and Color Picker.',
          ''
        ].join('\n');
      }

      async function ensureJsZipLoaded() {
        if (typeof window.JSZip !== 'undefined') return window.JSZip;
        await new Promise((resolve, reject) => {
          const s = document.createElement('script');
          s.src = 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js';
          s.crossOrigin = 'anonymous';
          s.referrerPolicy = 'no-referrer';
          s.onload = resolve;
          s.onerror = () => reject(new Error('Failed to load JSZip library'));
          document.head.appendChild(s);
        });
        if (typeof window.JSZip === 'undefined') {
          throw new Error('JSZip unavailable');
        }
        return window.JSZip;
      }

      async function getProjectCssText() {
        const inlineStyle = document.getElementById('appStyles');
        if (inlineStyle && inlineStyle.textContent.trim()) {
          return inlineStyle.textContent.trim() + '\n';
        }
        try {
          const res = await fetch('style.css');
          if (res.ok) return await res.text();
        } catch (_) {}
        return '';
      }

      async function getProjectJsText() {
        const inlineScript = document.getElementById('appScript');
        if (inlineScript && inlineScript.textContent.trim()) {
          return inlineScript.textContent.trim() + '\n';
        }
        try {
          const res = await fetch('app.js');
          if (res.ok) return await res.text();
        } catch (_) {}
        return '';
      }

      function triggerBlobDownload(blob, filename) {
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.rel = 'noopener';
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        setTimeout(() => URL.revokeObjectURL(url), 15000);
      }

      async function handleDownloadZip() {
        const labelSpan = downloadZipBtn.querySelector('span');
        const originalText = labelSpan ? labelSpan.textContent : 'Download ZIP';
        downloadZipBtn.disabled = true;
        if (labelSpan) labelSpan.textContent = 'Exporting...';

        try {
          const JSZipLib = await ensureJsZipLoaded();
          const [cssText, jsText] = await Promise.all([getProjectCssText(), getProjectJsText()]);
          const htmlText = buildExportedHtml();
          const readmeText = buildReadmeContent();

          const zip = new JSZipLib();
          zip.file('index.html', htmlText);
          zip.file('style.css', cssText);
          zip.file('app.js', jsText);
          zip.file('README.md', readmeText);

          const zipBlob = await zip.generateAsync({
            type: 'blob',
            compression: 'DEFLATE',
            compressionOptions: { level: 6 }
          });

          triggerBlobDownload(zipBlob, 'fl-studio-channel-rack.zip');
          const rect = downloadZipBtn.getBoundingClientRect();
          showHud('Downloaded fl-studio-channel-rack.zip', rect.left + rect.width / 2, rect.bottom + 42);
          setTimeout(hideHud, 1800);
        } catch (err) {
          const rect = downloadZipBtn.getBoundingClientRect();
          showHud('ZIP export requires JSZip CDN access', rect.left + rect.width / 2, rect.bottom + 42);
          setTimeout(hideHud, 2400);
        } finally {
          downloadZipBtn.disabled = false;
          if (labelSpan) labelSpan.textContent = originalText;
        }
      }

      /* ================= EVENT WIRING ================= */
      playBtn.addEventListener('click', () => {
        if (state.isPlaying) pausePlayback();
        else startPlayback();
      });

      stopBtn.addEventListener('click', () => {
        stopPlayback();
        stopBtn.classList.add('stopped-flash');
        setTimeout(() => stopBtn.classList.remove('stopped-flash'), 160);
      });

      clonePatternBtn.addEventListener('click', openClonePatternModal);
      downloadZipBtn.addEventListener('click', handleDownloadZip);
      channelOptionsBtn.addEventListener('click', openChannelOptionsModal);
      addChannelBtn.addEventListener('click', openAddChannelModal);

      globalSwingSlider.addEventListener('input', () => {
        state.swing = Number(globalSwingSlider.value);
        globalSwingVal.textContent = `${state.swing}%`;
      });

      graphEditorBtn.addEventListener('click', () => {
        state.graphEditorOpen = !state.graphEditorOpen;
        updateTransportUI();
        renderChannelList();
      });

      layoutToggleBtn.addEventListener('click', () => {
        const isCompact = document.body.classList.toggle('compact-16');
        layoutToggleBtn.textContent = isCompact ? '8×2 Touch' : '1×16 View';
      });

      window.addEventListener('keydown', (e) => {
        if (e.code === 'Space' && !modalBackdrop.classList.contains('open')) {
          e.preventDefault();
          if (state.isPlaying) pausePlayback();
          else startPlayback();
        }
      });

      /* ================= INIT ================= */
      renderPatternTabs();
      renderPlayheadRow();
      renderChannelList();
      updateTransportUI();
    })();
